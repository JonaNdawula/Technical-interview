﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace InterviewApp
{
    public partial class Login : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;


        void submit()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(" select * from bankusers where  Username =@name and password =@password and institutioncode=@code ",con);
                cmd.Parameters.AddWithValue("@name", TextBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@password", TextBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@code", DropDownList2.SelectedItem.ToString());
                SqlDataReader rd = cmd.ExecuteReader();
                if(rd.HasRows==true)
                {
                    Response.Redirect("Landingpage.aspx");

                }
                else 
                {
                    Response.Write("<script>alert('Invalid user name or password')</script>");
                }
            }
        }


         void submit2()
        {
            using (SqlConnection con2 = new SqlConnection(cs))
            {
                con2.Open();

                SqlCommand cmd2 = new SqlCommand("select* from Coporate where Username =@name and password =@password and institutioncode=@code ", con2);
                cmd2.Parameters.AddWithValue("@name", TextBox1.Text.Trim());
                cmd2.Parameters.AddWithValue("@password", TextBox2.Text.Trim());
                cmd2.Parameters.AddWithValue("@code", DropDownList2.SelectedItem.ToString());
                SqlDataReader rd2 = cmd2.ExecuteReader();
                if (rd2.HasRows == true)
                {
                    Response.Redirect("Landingpage.aspx");
                }

                else
                {
                    Response.Write("<script>alert('Invalid user name or password')</script>");
                }
            }
        }
         void submit3()
         {


             using (SqlConnection con3 = new SqlConnection(cs))
             {
                 con3.Open();

                 SqlCommand cmd3 = new SqlCommand(" select * from InterSwitchusers where  Username =@name and password =@password and institutioncode=@code ",con3);
                 cmd3.Parameters.AddWithValue("@name", TextBox1.Text.Trim());
                 cmd3.Parameters.AddWithValue("@password", TextBox2.Text.Trim());
                 cmd3.Parameters.AddWithValue("@code", DropDownList2.SelectedItem.ToString());

                 SqlDataReader rd3 = cmd3.ExecuteReader();

                 if(rd3.HasRows==true)
                 {
                     Response.Redirect("Landingpage.aspx");
                 }
                 else 
                 {
                     Response.Write("<script>alert('Invalid user name or password')</script>");
                 }

             }
         
         }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            submit();
            submit2();
            submit3();
            TextBox1.Text = "";
            TextBox2.Text = "";
          
        }

        protected void Button2_Click(object sender, EventArgs e)
        {    string s = DropDownList1.SelectedItem.ToString();
            Session["Name"] = s ;
            if (s != null)
            {
                Response.Redirect("Register.aspx");
            
            }
        }

      

        
    }
}