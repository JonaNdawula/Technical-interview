﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace InterviewApp
{
    public partial class Department : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        void deliver()
        {
            using (SqlConnection cn = new SqlConnection(cs))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("Insert into Department values(@Departmentname)", cn);
                cmd.Parameters.AddWithValue("@Departmentname",TextBox1.Text);
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Department created')</script>");

            }
        }
   
        void showgrid()
        {
            using(SqlConnection cn = new SqlConnection(cs))
            {
                cn.Open();
                SqlCommand cmd2 = new SqlCommand("Select * from Department",cn);
                SqlDataReader reader = cmd2.ExecuteReader();

                GridView1.DataSource = reader;
                GridView1.DataBind();


            }
        }
        
  
        protected void Page_Load(object sender, EventArgs e)
        {
            showgrid();
         
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            deliver();

            TextBox1.Text = "";
            Response.Redirect("Department.aspx");
        }
    }
}