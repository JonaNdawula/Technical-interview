﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace InterviewApp
{
    public partial class Landingpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["Name"]!=null)
            {

                try
                {
                    if (Session["Name"].Equals("Interswitch Employee"))
                    {
                        Button1.Visible = true;
                    }
                }
                catch (Exception Ex)
                {
                    Response.Write(Ex);

                }

            }

            if (Session["Name"] != null)
            {
                try
                {
                    if (Session["Name"].Equals("Coporate"))
                    {
                        Button1.Visible = false;
                    }
                }
                catch (Exception Ex)
                {
                    Response.Write(Ex);

                }

            }

            if (Session["Name"] != null)
            {
                try
                {
                    if (Session["Name"].Equals("Bank user"))
                    {
                        Button1.Visible = false;
                        
                    }
                }
                catch (Exception Ex)
                {
                    Response.Write(Ex);

                }


            }

        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Leaveregister.aspx");
        }
    }
}