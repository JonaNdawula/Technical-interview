﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
namespace InterviewApp
{
    public partial class Leaveregister : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        string constr = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        void insertData()
        {
            using (SqlConnection cnn = new SqlConnection(cs))
            {
                cnn.Open();
                SqlCommand cmd = new SqlCommand("Select * from EmployeeRegister ", cnn);
                SqlDataReader rd = cmd.ExecuteReader();

                GridView1.DataSource = rd;
                GridView1.DataBind();





            }

        }
        void submittoDB()
        {
            
           
              using( SqlConnection con = new SqlConnection(cs))
              {
                 
                 
                  con.Open();
                  SqlCommand cmd = new SqlCommand("insert into leave values(@Employee,@Leavestart,@leaveEnd,@Empid) ", con);
                  cmd.Parameters.AddWithValue("@Employee",TextBox1.Text);
                  cmd.Parameters.AddWithValue("@Leavestart",TextBox2.Text);
                  cmd.Parameters.AddWithValue("@leaveEnd",TextBox3.Text );
                  cmd.Parameters.AddWithValue("@Empid", DropDownList1.SelectedItem.ToString());
                   cmd.ExecuteNonQuery();

                  Response.Write("<script>alert('Successful Submission')</script>");

                   
              }
        
        
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            insertData();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("leaveview.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            submittoDB();
            Response.Redirect("Leaveregister.aspx");
        }
    }
}