﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
namespace InterviewApp
{
    public partial class EmployeeRecords : System.Web.UI.Page
    {
        string constring = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        void submission()
        {

            using (SqlConnection conn = new SqlConnection(constring))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("Insert into EmployeeRegister values(@firstn,@sname,@Address,@Telephone,@Gender,@Dob,@Email,@city,@country,@DepartmentId)", conn);
                cmd.Parameters.AddWithValue("@firstn",TextBox1.Text);
                cmd.Parameters.AddWithValue("@sname",TextBox2.Text);
                cmd.Parameters.AddWithValue("@Address",TextBox3.Text );
                cmd.Parameters.AddWithValue("@Telephone",TextBox4.Text );
                cmd.Parameters.AddWithValue("@Gender", DropDownList1.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Dob",TextBox5.Text);
                cmd.Parameters.AddWithValue("@Email", TextBox8.Text);
                cmd.Parameters.AddWithValue("@city",TextBox6.Text);
                cmd.Parameters.AddWithValue("@country", TextBox7.Text);
                cmd.Parameters.AddWithValue("@DepartmentId", DropDownList2.SelectedItem.ToString());

                cmd.ExecuteNonQuery();

                Response.Write("<script>alert('Data successfuly submitted')</script>");

            }

        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            submission();
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox8.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";
        }
    }
}