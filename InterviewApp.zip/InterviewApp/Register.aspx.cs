﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
namespace InterviewApp
{
    public partial class Register : System.Web.UI.Page
    {


        string cs = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
 
         void  insertIS()
        {
             using(SqlConnection con = new  SqlConnection(cs))
             {
                 con.Open();
                 SqlCommand cmd = new SqlCommand("insert into InterSwitchusers values(@userid,@username,@password,@lastname,@firstname,@email,@rolecode,@institutecode)", con);

                    cmd.Parameters.AddWithValue("@userid",   TextBox14.Text);
                    cmd.Parameters.AddWithValue("@username", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@password", TextBox4.Text);
                    cmd.Parameters.AddWithValue("@lastname", TextBox5.Text);

                    cmd.Parameters.AddWithValue("@firstname", TextBox2.Text);
                    cmd.Parameters.AddWithValue("@email", TextBox6.Text);
                    cmd.Parameters.AddWithValue("@rolecode", TextBox11.Text);
                    cmd.Parameters.AddWithValue("@institutecode", TextBox12.Text);

                    cmd.ExecuteNonQuery();

                    Response.Write("<script>alert('Data successfully submited')</script>");



              
             }

        }
         void insertCoporate()
         {
             using(SqlConnection con2 = new SqlConnection(cs))
             {
                 con2.Open();
                 SqlCommand cmd2 = new SqlCommand("insert into Coporate values(@userid,@username,@password,@lastname,@firstname,@email,@rolecode,@institutecode,@corpcode )", con2);
                 cmd2.Parameters.AddWithValue("@userid", TextBox14.Text);
                 cmd2.Parameters.AddWithValue("@username", TextBox1.Text);
                 cmd2.Parameters.AddWithValue("@password", TextBox4.Text);
                 cmd2.Parameters.AddWithValue("@lastname", TextBox5.Text);
                 cmd2.Parameters.AddWithValue("@firstname", TextBox2.Text);
                 cmd2.Parameters.AddWithValue("@email", TextBox6.Text);
                 cmd2.Parameters.AddWithValue("@rolecode", TextBox11.Text);
                 cmd2.Parameters.AddWithValue("@institutecode", TextBox12.Text);
                 cmd2.Parameters.AddWithValue("@corpcode ", TextBox15.Text);
                 cmd2.ExecuteNonQuery();
                 Response.Write("<script>alert('Data successfully submited')</script>");

             }
         }
        void insertbankuser()
        {
            using(SqlConnection con3 = new SqlConnection(cs))
            {
                con3.Open();
                SqlCommand cmd3 = new SqlCommand(" insert into bankusers values(@userid,@username,@password,@lastname,@firstname,@email,@rolecode,@icode,@Bcode )", con3);
                cmd3.Parameters.AddWithValue("@userid", TextBox14.Text);
                cmd3.Parameters.AddWithValue("@username", TextBox1.Text);
                cmd3.Parameters.AddWithValue("@password", TextBox4.Text);
                cmd3.Parameters.AddWithValue("@lastname", TextBox5.Text);
                cmd3.Parameters.AddWithValue("@firstname", TextBox2.Text);
                cmd3.Parameters.AddWithValue("@email", TextBox6.Text);
                cmd3.Parameters.AddWithValue("@rolecode", TextBox11.Text);
                cmd3.Parameters.AddWithValue("@icode", TextBox12.Text);
                cmd3.Parameters.AddWithValue("@Bcode", TextBox13.Text);
                cmd3.ExecuteNonQuery();
                Response.Write("<script>alert('Data successfully submited')</script>");
            }

        }

         void insertrole()
        {
             using(SqlConnection con = new SqlConnection(cs))
             {
                 con.Open();
                 SqlCommand cmd = new SqlCommand(" insert into roles values(@rolecode, @rolename,@RoleDescription)", con);
                 cmd.Parameters.AddWithValue("@rolecode", TextBox7.Text);
                 cmd.Parameters.AddWithValue("@rolename",TextBox3.Text);
                 cmd.Parameters.AddWithValue("@RoleDescription",TextBox8.Text);

                 cmd.ExecuteNonQuery();

                 Response.Write("<script>alert('Data successfully submited')</script>");
             }
        }
         void insertinstitution()
         {
             using(SqlConnection con = new SqlConnection(cs))
             {
                 con.Open();
                 SqlCommand cmd = new SqlCommand(" insert into institution values(@Icode,@institutionname)", con);
                 cmd.Parameters.AddWithValue("@Icode",TextBox9.Text);
                 cmd.Parameters.AddWithValue("@institutionname",TextBox10.Text);
                 cmd.ExecuteNonQuery();
                 Response.Write("<script>alert('Data successfully submited')</script>");
             }
         }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Name"] != null)
            {

                try
                {
                    if (Session["Name"].Equals("Interswitch Employee"))
                    {
                        Button2.Visible = false;
                        Button3.Visible = false;

                        Button5.Visible = false;
                        Button6.Visible = false;

                        Button8.Visible = false;
                        Button9.Visible = false;

                        Label16.Visible = false;
                        TextBox15.Visible = false;

                        Label14.Visible = false;
                        TextBox13.Visible = false;

                    }
                }
                catch (Exception Ex)
                {
                    Response.Write(Ex);

                }

            }

            if (Session["Name"] != null)
            {
                try
                {
                    if (Session["Name"].Equals("Coporate"))
                    {
                        Button1.Visible = false;
                        Button3.Visible = false;

                        Button4.Visible = false;
                        Button6.Visible = false;

                        Button7.Visible = false;
                        Button9.Visible = false;

                        Label14.Visible = false;
                        TextBox13.Visible = false;
                    }
                }
                catch (Exception Ex)
                {
                    Response.Write(Ex);

                }

            }

            if (Session["Name"] != null)
            {
                try
                {
                    if (Session["Name"].Equals("Bank user"))
                    {
                        Button1.Visible = false;
                        Button2.Visible = false;

                        Button4.Visible = false;
                        Button5.Visible = false;

                        Button7.Visible = false;
                        Button8.Visible = false;

                        Label16.Visible = false;
                        TextBox15.Visible = false;
                    }
                }
                catch (Exception Ex)
                {
                    Response.Write(Ex);

                }

            }

            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            insertIS();
            TextBox14.Text = "";
            TextBox1.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox2.Text = "";
            TextBox6.Text = "";
            TextBox11.Text = "";
            TextBox12.Text = "";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            insertCoporate();
            TextBox14.Text = "";
            TextBox1.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox2.Text = "";
            TextBox6.Text = "";
            TextBox11.Text = "";
            TextBox12.Text = "";
            TextBox15.Text = "";
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            insertbankuser();
            TextBox14.Text = "";
            TextBox1.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox2.Text = "";
            TextBox6.Text = "";
            TextBox11.Text = "";
            TextBox12.Text = "";
            TextBox13.Text = "";
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            insertrole();
            TextBox7.Text = "";
            TextBox3.Text = "";
            TextBox8.Text = "";
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            insertrole();
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            insertrole();
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            insertinstitution();
            TextBox10.Text = "";
            TextBox9.Text = "";
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            insertinstitution();
            TextBox10.Text = "";
            TextBox9.Text = "";
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            insertinstitution();
            TextBox10.Text = "";
            TextBox9.Text = "";
        }

        

    


    }
}